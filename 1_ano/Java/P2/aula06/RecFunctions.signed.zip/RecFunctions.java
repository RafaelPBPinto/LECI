public class RecFunctions {

   // Compute the volume of a pyramid of cubes with N layers.
   public int pyramidVolume(int N) {
      assert N >= 0;
      
      if(N > 0)
      {
         return pyramidVolume(N - 1) + N * N;
      }
      return 0;
   }

   public static int numberOfDigits(int value)
   {
      assert value >= 0;
      int n;
      if (value < 10)
         n = 1;
      else
         n = 1 + numberOfDigits(value / 10);
      return n;
   }

   public static String onlyCaps(String s)
   {
      String str = "";
      
      
      if(s.length() > 0)
      {
         
         
         char ch = s.charAt(0);            // the first character of s
         String tail = s.substring(1); 
         
         if (Character.isUpperCase(ch))
         {
            str += ch;
         }
         
         str += onlyCaps(tail);
         
         
      }
      
      return str;
      
   }

}
