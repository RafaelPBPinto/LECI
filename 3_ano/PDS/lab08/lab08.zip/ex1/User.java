public enum User {
	OWNER, COMPANY 
}
