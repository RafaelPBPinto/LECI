public abstract class Monitor {
        protected StudentAdm adm;

}
